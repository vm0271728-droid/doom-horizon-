#!/bin/sh
# Сборка мода в .hmod и копия в Загрузки (запускать внутри Ubuntu proot)
set -e
cd "$(dirname "$0")"
cargo horizon-mod build
if [ -d /sdcard/Download ]; then cp target/horizon-mod/hud_doom.hmod /sdcard/Download/ && ls -lh /sdcard/Download/hud_doom.hmod; else ls -lh target/horizon-mod/hud_doom.hmod; fi
echo "Готово: положи hud_doom.hmod в horizon-mods/ игры и перезапусти."
