# DOOM E1M1 для Horizon Android (.hmod)

Играбельный первый уровень DOOM (Hangar), рендер колонками по настоящей геометрии
из shareware doom1.wad (данные выпечены в src/e1m1.bin, 17 КБ).

## Управление (привязки игрока, как в Майне)
- WASD — ходьба (key.forward/back/left/right)
- ПКМ (use) — огонь
- ЛКМ (attack) — двери / выход
- Пробел (jump) — следующее оружие
- Красться (sneak) — поворот влево, спринт (sprint) — поворот вправо
  (мышь SDK не отдаёт, это единственный способ поворачивать)
- /doom — перезапуск уровня

## Сборка (Termux + proot Ubuntu, тулчейн как для остальных модов)
    sh build.sh

## Сборка на GitHub
Пуш в репозиторий запускает `.github/workflows/build.yml`; готовый `hud_doom.hmod` лежит в Artifacts запуска (Actions → build-hmod). Первая сборка долгая: ставится `cargo-horizon-mod`.

## Архив исходников
    sh pack.sh   # -> doom-e1m1-mod.zip, залей как релиз
