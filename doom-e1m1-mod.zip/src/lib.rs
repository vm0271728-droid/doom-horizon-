//! DOOM E1M1 — колоночный рендер по настоящей геометрии уровня из doom1.wad.
//! Автостарт при включении мода. Управление — привязки игрока (как в Майне):
//! WASD — ходьба · ПКМ (use) — огонь · ЛКМ (attack) — действие/двери ·
//! пробел (jump) — следующее оружие · красться/спринт — поворот влево/вправо.

use horizon_mod_sdk::{input, render, ui, Mod, Registration};

const DATA: &[u8] = include_bytes!("e1m1.bin");

const FOV: f64 = 70.0;
const EYE: f64 = 41.0;
const TURN: f64 = 2.6;
const SPEED: f64 = 2.1;
const RAD: f64 = 16.0;
const DOORS: [u16; 8] = [1, 26, 27, 28, 31, 32, 117, 118];
const EXITS: [u16; 3] = [11, 52, 124];
/// (тип, hp, цвет, скорость)
const MOBS: &[(u16, i32, u32, f64)] = &[
    (3000, 60, 0x8B4513, 1.7), // имп
    (3004, 20, 0x6B8E23, 1.4), // зомби
    (9, 30, 0xB22222, 1.5),    // дробовик
];
const WNAMES: [&str; 4] = ["", "Кулаки", "Пистолет", "Дробовик"];

struct Cur<'a> { d: &'a [u8], p: usize }
impl<'a> Cur<'a> {
    fn u8(&mut self) -> u8 { let v = self.d[self.p]; self.p += 1; v }
    fn u16(&mut self) -> u16 { let v = u16::from_le_bytes([self.d[self.p], self.d[self.p + 1]]); self.p += 2; v }
    fn i16(&mut self) -> i16 { self.u16() as i16 }
    fn u32(&mut self) -> u32 { let v = u32::from_le_bytes(self.d[self.p..self.p + 4].try_into().unwrap()); self.p += 4; v }
}

#[derive(Clone, Copy)]
struct Line { v1: u16, v2: u16, flags: u16, special: u16, tag: u16, side: u16 }
#[derive(Clone, Copy)]
struct Sec { fh: i16, ch: i16, light: u8, floor: u32, ceil: u32 }

struct Lvl {
    verts: Vec<(i32, i32)>,
    lines: Vec<Line>,
    sides: Vec<(u16, u32)>, // (сектор, цвет; 0xFFFFFFFF = проём)
    secs: Vec<Sec>,
    door_secs: Vec<(u16, u16)>, // (тег двери, сектор)
    pstart: (f64, f64, f64),
}

fn parse() -> Lvl {
    let mut c = Cur { d: DATA, p: 0 };
    c.u32(); c.u32(); // E1M1, ver
    let ntex = c.u16() as usize;
    let mut texc = Vec::with_capacity(ntex);
    for _ in 0..ntex { c.p += 8; texc.push(rgb(c.u8(), c.u8(), c.u8())); }
    let nfl = c.u16() as usize;
    let mut flatc = Vec::with_capacity(nfl);
    for _ in 0..nfl { c.p += 8; flatc.push(rgb(c.u8(), c.u8(), c.u8())); }
    let nv = c.u32() as usize;
    let mut verts = Vec::with_capacity(nv);
    for _ in 0..nv { verts.push((c.i16() as i32, c.i16() as i32)); }
    let ns = c.u32() as usize;
    let mut sides = Vec::with_capacity(ns);
    for _ in 0..ns {
        let sec = c.u16();
        let t = c.u16();
        sides.push((sec, if t == 0xFFFF { 0xFFFFFFFF } else { texc[t as usize] }));
    }
    let nl = c.u32() as usize;
    let mut lines = Vec::with_capacity(nl);
    for _ in 0..nl {
        lines.push(Line { v1: c.u16(), v2: c.u16(), flags: c.u16(), special: c.u16(), tag: c.u16(), side: c.u16() });
    }
    let nc = c.u16() as usize;
    let mut secs = Vec::with_capacity(nc);
    for _ in 0..nc {
        let fh = c.i16(); let ch = c.i16(); let light = c.u8();
        let floor = flatc[c.u8() as usize]; let ceil = flatc[c.u8() as usize];
        secs.push(Sec { fh, ch, light, floor, ceil });
    }
    let mut door_secs = Vec::new();
    for l in &lines {
        if DOORS.contains(&l.special) {
            let si = l.side as usize;
            if si != 0xFFFF { door_secs.push((l.tag, sides[si].0)); }
        }
    }
    let mut pstart = (0.0, 0.0, 0.0);
    let nt = c.u32() as usize;
    for _ in 0..nt {
        let x = c.i16() as f64; let y = c.i16() as f64; let a = c.i16() as f64; let t = c.u16();
        if t == 1 { pstart = (x, y, a); }
    }
    Lvl { verts, lines, sides, secs, door_secs, pstart }
}

fn rgb(r: u8, g: u8, b: u8) -> u32 { 0xFF000000 | ((r as u32) << 16) | ((g as u32) << 8) | b as u32 }

struct Mob { x: f64, y: f64, hp: i32, kind: usize, cool: u32, pain: u32 }
struct It { x: f64, y: f64, typ: u16, taken: bool }

struct Doom {
    lvl: Lvl,
    on: bool,
    px: f64, py: f64, ang: f64,
    hp: i32, armor: i32, bullets: i32, shells: i32,
    weapons: [bool; 4], cur: usize,
    mobs: Vec<Mob>, items: Vec<It>, proj: Vec<(f64, f64, f64, f64)>,
    doors: Vec<(u16, bool)>,
    pj: bool, pu: bool,
    cd: u32, flash: u32, hurt: u32, msg: String, msgt: u32,
    dead: u32, won: bool, rng: u32, t: u32,
}

fn dist2(x1: f64, y1: f64, x2: f64, y2: f64) -> f64 {
    let dx = x2 - x1; let dy = y2 - y1;
    (dx * dx + dy * dy).sqrt()
}

fn norm(mut a: f64) -> f64 {
    while a > 180.0 { a -= 360.0; }
    while a < -180.0 { a += 360.0; }
    a
}

impl Doom {
    fn new() -> Self {
        let mut s = Self {
            lvl: parse(), on: true,
            px: 0.0, py: 0.0, ang: 0.0,
            hp: 100, armor: 0, bullets: 50, shells: 0,
            weapons: [false, true, true, false], cur: 2,
            mobs: Vec::new(), items: Vec::new(), proj: Vec::new(), doors: Vec::new(),
            pj: false, pu: false, cd: 0, flash: 0, hurt: 0,
            msg: String::new(), msgt: 0, dead: 0, won: false, rng: 12345, t: 0,
        };
        s.reset();
        s
    }
    fn reset(&mut self) {
        let (x, y, a) = self.lvl.pstart;
        self.px = x; self.py = y; self.ang = a;
        self.hp = 100; self.armor = 0; self.bullets = 50; self.shells = 0;
        self.weapons = [false, true, true, false]; self.cur = 2;
        self.mobs.clear(); self.items.clear(); self.proj.clear(); self.doors.clear();
        self.cd = 0; self.flash = 0; self.hurt = 0; self.dead = 0; self.won = false;
        // перечитываем объекты из DATA
        let mut c = Cur { d: DATA, p: 0 };
        c.u32(); c.u32();
        let ntex = c.u16() as usize; c.p += 11 * ntex;
        let nfl = c.u16() as usize; c.p += 11 * nfl;
        c.p += 4 + 4 * (c.u32() as usize);
        c.p += 4 + 4 * (c.u32() as usize);
        c.p += 4 + 12 * (c.u32() as usize);
        let nc = c.u16() as usize; c.p += 7 * nc;
        let nt = c.u32() as usize;
        for _ in 0..nt {
            let x = c.i16() as f64; let y = c.i16() as f64; let _a = c.u16(); let tp = c.u16();
            if let Some(k) = MOBS.iter().position(|m| m.0 == tp) {
                self.mobs.push(Mob { x, y, hp: MOBS[k].1, kind: k, cool: 30, pain: 0 });
            } else if matches!(tp, 2011 | 2012 | 2018 | 2001 | 2014 | 2008) {
                self.items.push(It { x, y, typ: tp, taken: false });
            }
        }
        self.say("E1M1: HANGAR");
    }
    fn rnd(&mut self) -> i32 {
        self.rng = self.rng.wrapping_mul(1103515245).wrapping_add(12345);
        ((self.rng >> 16) & 0x7FFF) as i32
    }
    fn say(&mut self, m: &str) { self.msg = m.into(); self.msgt = 90; }
    fn door_open(&self, tag: u16) -> bool { self.doors.iter().any(|&(t, o)| t == tag && o) }
    fn blocked(&self, l: &Line) -> bool {
        if l.flags & 1 == 0 { return false; }
        if DOORS.contains(&l.special) && self.door_open(l.tag) { return false; }
        true
    }
    fn circle_hits(&self, x: f64, y: f64) -> bool {
        for l in &self.lvl.lines {
            if !self.blocked(l) { continue; }
            let (x1, y1) = self.lvl.verts[l.v1 as usize];
            let (x2, y2) = self.lvl.verts[l.v2 as usize];
            let dx = (x2 - x1) as f64; let dy = (y2 - y1) as f64;
            let len2 = dx * dx + dy * dy;
            if len2 < 1.0 { continue; }
            let mut t = ((x - x1 as f64) * dx + (y - y1 as f64) * dy) / len2;
            t = t.clamp(0.0, 1.0);
            let cx = x1 as f64 + t * dx; let cy = y1 as f64 + t * dy;
            if dist2(x, y, cx, cy) < RAD { return true; }
        }
        false
    }
    fn mv(&mut self, who: usize, dx: f64, dy: f64) {
        // who: 0 = игрок, иначе индекс моба+1
        let (mut x, mut y) = match who { 0 => (self.px, self.py), w => (self.mobs[w - 1].x, self.mobs[w - 1].y) };
        if !self.circle_hits(x + dx, y) { x += dx; }
        if !self.circle_hits(x, y + dy) { y += dy; }
        match who { 0 => { self.px = x; self.py = y; }, w => { self.mobs[w - 1].x = x; self.mobs[w - 1].y = y; } }
    }
    /// Луч под углом a (градусы, 0 = +X). Возвращает (дист, цвет стены, сектор).
    fn ray(&self, a: f64) -> (f64, u32, u16) {
        let dx = a.to_radians().cos(); let dy = a.to_radians().sin();
        let mut best = (f64::MAX, 0xFF808080, 0u16);
        for l in &self.lvl.lines {
            let si = l.side as usize;
            if si == 0xFFFF { continue; }
            let (col, sec) = self.lvl.sides[si];
            if col == 0xFFFFFFFF { continue; }
            let (x1, y1) = self.lvl.verts[l.v1 as usize];
            let (x2, y2) = self.lvl.verts[l.v2 as usize];
            let ex = (x2 - x1) as f64; let ey = (y2 - y1) as f64;
            let den = dx * ey - dy * ex;
            if den.abs() < 1e-9 { continue; }
            let t = ((x1 as f64 - self.px) * ey - (y1 as f64 - self.py) * ex) / den;
            let u = ((x1 as f64 - self.px) * dy - (y1 as f64 - self.py) * dx) / -den;
            if t > 0.5 && u >= 0.0 && u <= 1.0 && t < best.0 {
                best = (t, col, sec);
            }
        }
        best
    }
    /// Луч для взаимодействия: ближайшая линия со спец-кодом в пределах dist.
    fn ray_special(&self, a: f64, maxd: f64) -> Option<Line> {
        let dx = a.to_radians().cos(); let dy = a.to_radians().sin();
        let mut best = (maxd, None);
        for l in &self.lvl.lines {
            if l.special == 0 { continue; }
            let si = l.side as usize;
            if si == 0xFFFF { continue; }
            if self.lvl.sides[si].1 == 0xFFFFFFFF { continue; }
            let (x1, y1) = self.lvl.verts[l.v1 as usize];
            let (x2, y2) = self.lvl.verts[l.v2 as usize];
            let ex = (x2 - x1) as f64; let ey = (y2 - y1) as f64;
            let den = dx * ey - dy * ex;
            if den.abs() < 1e-9 { continue; }
            let t = ((x1 as f64 - self.px) * ey - (y1 as f64 - self.py) * ex) / den;
            let u = ((x1 as f64 - self.px) * dy - (y1 as f64 - self.py) * dx) / -den;
            if t > 4.0 && t < best.0 && u >= -0.02 && u <= 1.02 {
                best = (t, Some(*l));
            }
        }
        best.1
    }
    fn fh_eff(&self, sec: u16) -> i16 {
        let s = &self.lvl.secs[sec as usize];
        if self.lvl.door_secs.iter().any(|&(_, ds)| ds == sec && self.door_open(self.lvl.door_secs.iter().find(|&&(_, ds)| ds == sec).unwrap().0)) {
            return s.ch - 4;
        }
        s.fh
    }
    fn pdmg(&mut self, d: i32) {
        if self.dead > 0 || self.won { return; }
        let ab = (d / 3).min(self.armor);
        self.armor -= ab;
        self.hp -= d - ab;
        self.hurt = 12;
        if self.hp <= 0 { self.hp = 0; self.dead = 150; self.say(""); }
    }
    fn hitscan(&mut self, a: f64, range: f64, dmg: i32) {
        let (wall, _, _) = self.ray(a);
        let lim = wall.min(range);
        for m in &mut self.mobs {
            if m.hp <= 0 { continue; }
            let d = dist2(self.px, self.py, m.x, m.y);
            if d > lim { continue; }
            let rel = norm((m.y - self.py).atan2(m.x - self.px).to_degrees() - a).abs();
            if rel < (20.0 / d.max(1.0)).to_degrees().max(1.5) {
                m.hp -= dmg; m.pain = 10; m.cool = m.cool.min(10);
            }
        }
    }
    fn fire(&mut self) {
        if self.cd > 0 || self.dead > 0 || self.won { return; }
        match self.cur {
            1 => { self.cd = 28; self.hitscan(self.ang, 60.0, self.rnd() % 15 + 4); }
            2 => {
                if self.bullets <= 0 { self.say("Нет патронов"); self.cd = 20; return; }
                self.bullets -= 1; self.cd = 13; self.flash = 4;
                self.hitscan(self.ang + (self.rnd() % 30 - 15) as f64 / 10.0, 1500.0, self.rnd() % 11 + 4);
            }
            3 => {
                if self.shells <= 0 { self.say("Нет дроби"); self.cd = 25; return; }
                self.shells -= 1; self.cd = 38; self.flash = 6;
                for _ in 0..7 {
                    let a = self.ang + (self.rnd() % 100 - 50) as f64 / 10.0;
                    self.hitscan(a, 800.0, self.rnd() % 7 + 3);
                }
            }
            _ => {}
        }
    }
    fn tick(&mut self) {
        self.t += 1;
        if self.cd > 0 { self.cd -= 1; }
        if self.flash > 0 { self.flash -= 1; }
        if self.hurt > 0 { self.hurt -= 1; }
        if self.msgt > 0 { self.msgt -= 1; }
        if self.dead > 0 { self.dead -= 1; if self.dead == 0 { self.reset(); } return; }
        if self.won { return; }

        let m = |k: &str| input::mapping(k).map_or(false, |s| s.down);
        if m("key.sneak") { self.ang += TURN; }
        if m("key.sprint") { self.ang -= TURN; }
        let f = (m("key.forward") as i32) - (m("key.back") as i32);
        let s = (m("key.left") as i32) - (m("key.right") as i32);
        if f != 0 || s != 0 {
            let ar = self.ang.to_radians();
            let k = if f != 0 && s != 0 { 0.707 } else { 1.0 };
            let dx = (ar.cos() * f as f64 + (-ar.sin()) * s as f64) * SPEED * k;
            let dy = (ar.sin() * f as f64 + ar.cos() * s as f64) * SPEED * k;
            self.mv(0, dx, dy);
        }
        let jump = m("key.jump");
        if jump && !self.pj {
            for i in 1..4 {
                let n = (self.cur + i) % 4;
                if n != 0 && self.weapons[n] { self.cur = n; self.say(WNAMES[n]); break; }
            }
        }
        self.pj = jump;
        if m("key.attack") { self.fire(); }
        let use = m("key.use");
        if use && !self.pu {
            if let Some(l) = self.ray_special(self.ang, 96.0) {
                if DOORS.contains(&l.special) {
                    match self.doors.iter_mut().find(|d| d.0 == l.tag) {
                        Some(d) => d.1 = !d.1,
                        None => self.doors.push((l.tag, true)),
                    }
                    self.say("Дверь");
                } else if EXITS.contains(&l.special) {
                    self.won = true;
                }
            }
        }
        self.pu = use;

        // монстры
        for i in 0..self.mobs.len() {
            if self.mobs[i].hp <= 0 { continue; }
            if self.mobs[i].pain > 0 { self.mobs[i].pain -= 1; continue; }
            let (mx, my) = (self.mobs[i].x, self.mobs[i].y);
            let d = dist2(mx, my, self.px, self.py);
            let (kind, mut cool) = (self.mobs[i].kind, self.mobs[i].cool);
            if cool > 0 { cool -= 1; }
            if d < 48.0 {
                if cool == 0 {
                    self.pdmg(self.rnd() % 9 + 4);
                    cool = 30;
                }
            } else if d < 1200.0 {
                let a = (self.py - my).atan2(self.px - mx);
                self.mv(i + 1, a.cos() * MOBS[kind].3, a.sin() * MOBS[kind].3);
                if cool == 0 && d < 700.0 {
                    match kind {
                        0 => { // имп: файерболл
                            let sp = 2.4;
                            self.proj.push((mx, my, (self.px - mx) / d * sp, (self.py - my) / d * sp));
                            cool = 55;
                        }
                        1 => { self.pdmg(self.rnd() % 9 + 3); cool = 35; }
                        _ => { for _ in 0..3 { self.pdmg(self.rnd() % 7 + 3); } cool = 50; }
                    }
                }
            }
            self.mobs[i].cool = cool;
        }
        // файерболлы
        let mut k = 0;
        while k < self.proj.len() {
            let (mut x, mut y, dx, dy) = self.proj[k];
            x += dx; y += dy;
            if self.circle_hits(x, y) { self.proj.remove(k); continue; }
            if dist2(x, y, self.px, self.py) < 20.0 {
                self.pdmg(self.rnd() % 10 + 3);
                self.proj.remove(k);
                continue;
            }
            self.proj[k] = (x, y, dx, dy);
            k += 1;
        }
        // подбор предметов
        for it in &mut self.items {
            if it.taken || dist2(it.x, it.y, self.px, self.py) > 26.0 { continue; }
            it.taken = true;
            match it.typ {
                2011 => { self.hp = (self.hp + 10).min(100); self.say("Аптечка +10"); }
                2012 => { self.hp = (self.hp + 25).min(100); self.say("Медпак +25"); }
                2018 => { self.armor = 100; self.say("Броня"); }
                2001 => { self.weapons[3] = true; self.cur = 3; self.say("Дробовик!"); }
                2014 => { self.bullets += 10; self.say("Обойма +10"); }
                2008 => { self.shells += 4; self.say("Дробь +4"); }
                _ => {}
            }
        }
    }
    fn shade(&self, c: u32, light: u8, dist: f64, ceil: bool) -> u32 {
        let mut k = (light as f64 / 255.0) * (220.0 / (220.0 + dist));
        if ceil { k *= 1.25; }
        k = k.clamp(0.08, 1.3);
        let r = (((c >> 16) & 0xFF) as f64 * k) as u32;
        let g = (((c >> 8) & 0xFF) as f64 * k) as u32;
        let b = ((c & 0xFF) as f64 * k) as u32;
        0xFF000000 | (r << 16) | (g << 8) | b
    }
    fn fill(x: f32, y: f32, w: f32, h: f32, color: u32) -> render::Shape {
        render::Shape::Fill(render::FillShape { rect: render::Rect { x, y, w: w.max(0.0), h: h.max(0.0) }, color })
    }
    fn txt(s: String, x: f32, y: f32, color: u32) -> render::Shape {
        render::Shape::Text(render::TextShape { text: s, at: render::Point { x, y }, color, centered: false, shadow: true })
    }
    fn render(&self) {
        if !self.on { render::set_hud(&[]); return; }
        let (sw, sh) = render::gui_size();
        let cols = 128;
        let colw = sw / cols as f32;
        let focal = (sh / 2.0) / 0.7002075;
        let horizon = sh * 0.48;
        let mut v: Vec<render::Shape> = Vec::with_capacity(700);
        for i in 0..cols {
            let a = self.ang - FOV / 2.0 + FOV * i as f64 / (cols as f64 - 1.0);
            let (dist, col, sec) = self.ray(a);
            if dist > 30000.0 { continue; }
            let s = &self.lvl.secs[sec as usize];
            let fh = self.fh_eff(sec);
            let x = i as f32 * colw;
            let top = horizon - (focal * (s.ch as f64 - EYE) / dist) as f32;
            let bot = horizon + (focal * (EYE - fh as f64) / dist) as f32;
            v.push(Self::fill(x, 0.0, colw + 0.6, top, self.shade(s.ceil, s.light, dist, true)));
            v.push(Self::fill(x, top, colw + 0.6, bot - top, self.shade(col, s.light, dist, false)));
            v.push(Self::fill(x, bot, colw + 0.6, sh - bot, self.shade(s.floor, s.light, dist, false)));
        }
        // спрайты: монстры, предметы, файерболлы
        let mut sp: Vec<(f64, f32, f32, f32, u32)> = Vec::new();
        let mut push = |x: f64, y: f64, hgt: f64, color: u32| {
            let d = dist2(x, y, self.px, self.py);
            let rel = norm((y - self.py).atan2(x - self.px).to_degrees() - self.ang);
            if rel.abs() > 42.0 { return; }
            let sx = sw / 2.0 + (focal * rel.to_radians().tan()) as f32;
            let h2 = (focal * hgt / d) as f32;
            let bot = horizon + (focal * EYE / d) as f32;
            sp.push((d, sx - h2 * 0.35, bot - h2, h2, color));
        };
        for m in &self.mobs {
            if m.hp > 0 { push(m.x, m.y, 36.0, if m.pain > 5 { 0xFFFFFFFF } else { MOBS[m.kind].2 }); }
        }
        for it in &self.items {
            if !it.taken {
                push(it.x, it.y, 14.0, match it.typ {
                    2011 => 0xFFDDDDDD, 2012 => 0xFFFFFFFF, 2018 => 0xFF22CC44,
                    2001 => 0xFF4444CC, 2014 => 0xFFDDCC44, _ => 0xFFCC4444,
                });
            }
        }
        for p in &self.proj { push(p.0, p.1, 10.0, 0xFFFF6622); }
        sp.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
        for (_, x, y, h2, c) in sp {
            v.push(Self::fill(x, y, h2 * 0.7, h2, c | 0xFF000000));
        }
        // вспышка выстрела
        if self.flash > 0 {
            v.push(Self::fill(sw / 2.0 - 26.0, sh - 54.0, 52.0, 34.0, 0xFFFFF2AA));
        }
        // худ
        v.push(Self::fill(0.0, sh - 18.0, sw, 18.0, 0xD0000000));
        v.push(Self::txt(format!("HP {}  БР {}", self.hp, self.armor), 6.0, sh - 14.0, if self.hp > 30 { 0xFFFFFF } else { 0xFF5555 }));
        v.push(Self::txt(format!("{}  п:{} д:{}", WNAMES[self.cur], self.bullets, self.shells), sw - 130.0, sh - 14.0, 0xFFCC66));
        if self.msgt > 0 && !self.msg.is_empty() {
            v.push(Self::txt(self.msg.clone(), sw / 2.0 - 60.0, sh - 34.0, 0xFFFFAA));
        }
        if self.hurt > 0 { v.push(Self::fill(0.0, 0.0, sw, sh, 0x35FF0000)); }
        if self.dead > 0 {
            v.push(Self::fill(0.0, 0.0, sw, sh, 0x90000000));
            v.push(Self::txt("ВЫ ПОГИБЛИ".into(), sw / 2.0 - 46.0, sh / 2.0 - 10.0, 0xFF3333));
        }
        if self.won {
            v.push(Self::fill(0.0, 0.0, sw, sh, 0x90000000));
            v.push(Self::txt("УРОВЕНЬ ПРОЙДЕН!".into(), sw / 2.0 - 60.0, sh / 2.0 - 10.0, 0x55FF55));
            v.push(Self::txt("/doom — заново".into(), sw / 2.0 - 44.0, sh / 2.0 + 6.0, 0xAAAAAA));
        }
        render::set_hud(&v);
    }
}

impl Mod for Doom {
    fn init() -> Result<(Self, Registration), String> {
        Ok((Doom::new(), Registration::new().on_tick().on_frame().command("doom")))
    }
    fn tick(&mut self, _t: u64) { if self.on { self.tick(); } }
    fn frame(&mut self, _s: f32) { self.render(); }
    fn command(&mut self, name: &str, _a: &str) -> Result<Option<String>, String> {
        if name == "doom" { self.reset(); return Ok(Some("DOOM: перезапуск".into())); }
        Ok(None)
    }
    fn ui_select(&mut self, id: u32, _row: u32) {
        if id == 101 { self.on = !self.on; }
    }
    fn ui_settings_opened(&mut self) {
        ui::set_settings(&[
            ui::Widget::Button(ui::ButtonWidget { id: 101, label: format!("DOOM: {}", if self.on { "ON" } else { "OFF" }) }),
            ui::Widget::Text(ui::TextWidget { id: 110, text: "WASD ходьба · ПКМ огонь · ЛКМ двери · пробел оружие · красться/спринт поворот".into(), color: 0xAAAAAA }),
        ]);
    }
}

horizon_mod_sdk::export_mod!(Doom);
