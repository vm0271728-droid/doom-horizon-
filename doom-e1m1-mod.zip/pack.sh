#!/bin/sh
# Упаковка исходников в zip для GitHub (без target/)
cd "$(dirname "$0")"
rm -f ../doom-e1m1-mod.zip
zip -r ../doom-e1m1-mod.zip . -x "target/*" -x "*.zip"
echo "Создан: $(dirname "$0")/../doom-e1m1-mod.zip"
